from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select

from ..campaigns import get_campaign, list_campaigns
from ..context import Ctx
from ..db import Policy, now_iso
from ..deps import Principal, get_ctx, require
from ..policy import BUILTIN_RULES, is_safe_regex

router = APIRouter(prefix="/blue", tags=["blue-team"])


class PolicyIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    kind: Literal["keyword", "regex"]
    pattern: str = Field(min_length=1, max_length=200)
    action: Literal["block", "flag"] = "block"
    severity: Literal["low", "medium", "high", "critical"] = "high"


def _p(p: Policy) -> dict:
    return {"id": p.id, "name": p.name, "kind": p.kind, "pattern": p.pattern, "action": p.action,
            "severity": p.severity, "enabled": p.enabled, "created_by": p.created_by, "created_at": p.created_at}


@router.get("/stats")
def stats(_: Principal = Depends(require("stats:read")), ctx: Ctx = Depends(get_ctx)):
    c = ctx.audit.counts()
    last = list_campaigns(ctx, None)[:1]
    return {**c, "last_campaign": last[0] if last else None}


@router.get("/audit")
def audit(limit: int = Query(100, ge=1, le=500), before_seq: int | None = None,
          event_prefix: str | None = Query(None, max_length=32),
          _: Principal = Depends(require("audit:read")), ctx: Ctx = Depends(get_ctx)):
    return ctx.audit.list(limit=limit, before_seq=before_seq, event_prefix=event_prefix)


@router.get("/audit/verify")
def verify(_: Principal = Depends(require("audit:verify")), ctx: Ctx = Depends(get_ctx)):
    return ctx.audit.verify()


@router.get("/alerts")
def alerts(limit: int = Query(100, ge=1, le=500), since_seq: int | None = None,
           _: Principal = Depends(require("alerts:read")), ctx: Ctx = Depends(get_ctx)):
    return ctx.audit.list(limit=limit, event_prefix="alert.", min_seq=since_seq)


@router.get("/campaigns")
def campaigns(_: Principal = Depends(require("campaign:read_all")), ctx: Ctx = Depends(get_ctx)):
    return list_campaigns(ctx, None)


@router.get("/campaigns/{cid}")
def campaign(cid: str, _: Principal = Depends(require("campaign:read_all")), ctx: Ctx = Depends(get_ctx)):
    c = get_campaign(ctx, cid)
    if not c:
        raise HTTPException(404, "Not found")
    return c


@router.get("/rules")
def builtin_rules(_: Principal = Depends(require("policy:read"))):
    return [{"id": r.id, "category": r.category, "action": r.action, "severity": r.severity,
             "description": r.description} for r in BUILTIN_RULES]


@router.get("/policies")
def policies(_: Principal = Depends(require("policy:read")), ctx: Ctx = Depends(get_ctx)):
    with ctx.sf() as s:
        return [_p(p) for p in s.execute(select(Policy).order_by(Policy.id)).scalars()]


@router.post("/policies", status_code=201)
def add_policy(body: PolicyIn, who: Principal = Depends(require("policy:write")), ctx: Ctx = Depends(get_ctx)):
    if body.kind == "regex":
        ok, why = is_safe_regex(body.pattern)
        if not ok:
            raise HTTPException(422, why)
    with ctx.sf() as s, s.begin():
        p = Policy(name=body.name, kind=body.kind, pattern=body.pattern, action=body.action,
                   severity=body.severity, enabled=True, created_by=who.username, created_at=now_iso())
        s.add(p)
        s.flush()
        out = _p(p)
    ctx.audit.append(actor=who.username, role=who.role, event_type="policy.created", severity="info",
                     source_ip=who.ip, details={"policy_id": out["id"], "name": body.name, "kind": body.kind})
    return out


@router.delete("/policies/{pid}", status_code=204)
def delete_policy(pid: int, who: Principal = Depends(require("policy:write")), ctx: Ctx = Depends(get_ctx)):
    with ctx.sf() as s, s.begin():
        p = s.get(Policy, pid)
        if not p:
            raise HTTPException(404, "Not found")
        s.delete(p)
    ctx.audit.append(actor=who.username, role=who.role, event_type="policy.deleted", severity="info",
                     source_ip=who.ip, details={"policy_id": pid})
