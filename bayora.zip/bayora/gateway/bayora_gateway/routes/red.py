from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..attacks import CATEGORIES, load_attacks
from ..campaigns import get_campaign, list_campaigns, red_view, run_campaign
from ..context import Ctx
from ..deps import Principal, get_ctx, require
from ..pipeline import run_prompt

router = APIRouter(prefix="/red", tags=["red-team"])


class ProbeIn(BaseModel):
    prompt: str = Field(min_length=1, max_length=20000)
    mode: Literal["enforce", "monitor"] = "enforce"


class CampaignIn(BaseModel):
    categories: list[Literal["prompt_injection", "jailbreak", "data_leakage", "obfuscation", "benign"]] = []
    mode: Literal["enforce", "monitor"] = "enforce"


@router.get("/attacks")
def attacks(_: Principal = Depends(require("llm:probe"))):
    return [{k: a[k] for k in ("id", "category", "severity", "name", "prompt")} for a in load_attacks()]


@router.post("/probe")
def probe(body: ProbeIn, who: Principal = Depends(require("llm:probe")), ctx: Ctx = Depends(get_ctx)):
    r = run_prompt(ctx, who, body.prompt, body.mode)
    return {"blocked": r["blocked"], "response": r["response"], "leaked": r["leaked"],
            "unsafe": r["unsafe"], "latency_ms": r["latency_ms"]}


@router.post("/campaigns")
def campaign(body: CampaignIn, who: Principal = Depends(require("campaign:run")), ctx: Ctx = Depends(get_ctx)):
    return red_view(run_campaign(ctx, who, body.categories, body.mode))


@router.get("/campaigns")
def my_campaigns(who: Principal = Depends(require("campaign:read_own")), ctx: Ctx = Depends(get_ctx)):
    return list_campaigns(ctx, None if who.role == "admin" else who.username)


@router.get("/campaigns/{cid}")
def my_campaign(cid: str, who: Principal = Depends(require("campaign:read_own")), ctx: Ctx = Depends(get_ctx)):
    c = get_campaign(ctx, cid)
    if not c or (who.role != "admin" and c["created_by"] != who.username):
        raise HTTPException(404, "Not found")
    return red_view(c)
