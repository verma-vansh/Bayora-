import time
from collections import defaultdict, deque

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select

from ..context import Ctx
from ..db import User
from ..deps import Principal, client_ip, get_ctx, get_principal
from ..security import create_token, hash_password, verify_password

router = APIRouter(tags=["auth"])
_failures: dict[tuple, deque] = defaultdict(deque)
_DUMMY = hash_password("not-a-real-password")
LOCK_WINDOW = 300


class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)


@router.post("/auth/login")
def login(body: LoginIn, request: Request, ctx: Ctx = Depends(get_ctx)):
    ip, key, now = client_ip(request), (client_ip(request), body.username.lower()), time.monotonic()
    q = _failures[key]
    while q and now - q[0] > LOCK_WINDOW:
        q.popleft()
    if len(q) >= ctx.settings.login_max_failures:
        ctx.audit.append(actor=body.username[:64], role="anon", event_type="auth.locked_out",
                         severity="high", source_ip=ip, details={})
        raise HTTPException(429, "Too many failed attempts. Try again later.")
    with ctx.sf() as s:
        user = s.execute(select(User).where(User.username == body.username)).scalar_one_or_none()
    ok = verify_password(body.password, user.password_hash if user else _DUMMY) and user is not None
    if not ok:
        q.append(now)
        ctx.audit.append(actor=body.username[:64], role="anon", event_type="auth.failure",
                         severity="medium", source_ip=ip, details={})
        ctx.detector.on_auth_failure(ip, body.username)
        raise HTTPException(401, "Invalid credentials")
    q.clear()
    ctx.audit.append(actor=user.username, role=user.role, event_type="auth.success", severity="info",
                     source_ip=ip, details={})
    token = create_token(ctx.settings.jwt_secret, user.username, user.role, ctx.settings.jwt_ttl_minutes)
    return {"access_token": token, "token_type": "bearer", "role": user.role,
            "expires_in": ctx.settings.jwt_ttl_minutes * 60}


@router.get("/me")
def me(who: Principal = Depends(get_principal)):
    return {"username": who.username, "role": who.role, "capabilities": sorted(who.caps)}
